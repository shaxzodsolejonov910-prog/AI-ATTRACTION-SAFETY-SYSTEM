/*
  Kema attraksioni — to'liq kod
  Arduino Uno + L298N + aktuator + N20 + LCD 1602 (I2C) + MPU6050 + 4 tugma + buzzer

  Pinlar:
    D2  Aktuator tugmasi        D5  L298N ENA     D6  L298N ENB
    D3  N20 tugmasi             D7  L298N IN1     D10 L298N IN3
    D4  Favqulod tugma          D8  L298N IN2     D11 L298N IN4
    D12 START tugmasi           A4  SDA (LCD + MPU6050)
    D9  Buzzer (+)              A5  SCL (LCD + MPU6050)
    D13 Platadagi L chirog'i (favqulod)

  Kerakli kutubxona: "LiquidCrystal I2C" (Frank de Brabander)
*/

#include <Wire.h>
#include <LiquidCrystal_I2C.h>

LiquidCrystal_I2C lcd(0x27, 16, 2);   // ekranda hech narsa chiqmasa 0x3F qilib ko'ring

// ---------- Aktuator (L298N A kanali) ----------
const int ENA = 5;
const int IN1 = 7;
const int IN2 = 8;
const int TUGMA_AKT = 2;

const bool TESKARI = true;           // aktuator teskari yursa, true qiling
const int TEZLIK_YUQORI = 255;        // ko'tarilish tezligi (0–255)
const int TEZLIK_PAST   = 255;        // tushish tezligi (0–255)

// ---------- N20 motor (L298N B kanali) ----------
const int ENB = 6;
const int IN3 = 10;
const int IN4 = 11;
const int TUGMA_N20 = 3;

const int TEZLIK_N20 = 200;           // N20 tezligi (0–255)
const bool N20_TESKARI = false;       // N20 teskari aylansa, true qiling

// N20 ikki tomonga navbat bilan aylanadi
const unsigned long N20_YON_MS   = 3000; // bir tomonga necha ms aylansin (3000 = 3 soniya)
const unsigned long N20_PAUZA_MS = 300;  // yo'nalish almashishidan oldin to'xtash (motorni asraydi)

// ---------- Favqulod ----------
const int TUGMA_FAVQULOD = 4;
const int CHIROQ = 13;
const unsigned long KOTARISH_MS = 800; // favqulodda aktuator qancha ko'tarilsin

// ---------- START va buzzer ----------
const int TUGMA_START = 12;
const int BUZZER = 9;
const bool AKTIV_BUZZER = false;       // ovoz g'alati chiqsa, true qilib ko'ring
const unsigned long SANASH_MS = 3000;  // START dan keyin 3 soniya

// ---------- MPU6050 ----------
const int MPU = 0x68;
const float OGISH_CHEGARA = 30.0;      // gradus
const float HARORAT_CHEGARA = 60.0;    // °C

// ---------- Ekran ----------
const unsigned long XABAR_MS = 2000;
const char GRADUS = (char)223;

// ---------- Tizim holati ----------
enum Rejim { KUTISH, SANASH, ISHLAYAPTI };
Rejim rejim = KUTISH;
unsigned long rejim_boshlandi = 0;

// Aktuator holati
bool oldingi_bosilgan = false;
unsigned long boshlandi = 0;
int akt_holat = 0;                     // 1 = UP, -1 = DN, 0 = to'xtagan

// N20 holati
bool n20_yoqiq = false;
bool n20_ishlayapti = false;
int n20_yon = 1;                       // 1 = oldinga, -1 = orqaga, 0 = pauza
unsigned long n20_yon_boshlandi = 0;   // shu yo'nalish boshlangan vaqt
int n20_oldingi = HIGH;
unsigned long n20_oxirgi_bosish = 0;

// Kutish paytida aktuator tugmasini sezish uchun
int akt_k_oldingi = HIGH;
unsigned long akt_k_oxirgi = 0;

// START tugmasi
int start_oldingi = HIGH;
unsigned long start_oxirgi = 0;

// Buzzer
bool buzzer_holat = false;

// Favqulod holati
bool favqulod = false;
int fav_oldingi = HIGH;
unsigned long fav_oxirgi_bosish = 0;
unsigned long fav_boshlandi = 0;
char sabab[17] = "";

// MPU holati
bool mpu_bor = false;
float nol_oldinga = 0, nol_yonga = 0;
float oldinga = 0, yonga = 0;
float harorat = 0;
int ogish_soni = 0;
unsigned long mpu_oxirgi = 0;

// Ekran holati
char xabar1[17] = "", xabar2[17] = "";
bool xabar_bor = false;
unsigned long xabar_vaqt = 0;
char ekran1[17] = "", ekran2[17] = "";
unsigned long ekran_oxirgi = 0;

// ================= Aktuator =================
unsigned long yurish_vaqti(int tezlik) {
  return 2000UL * 255 / tezlik;
}
void yuqoriga() {
  digitalWrite(IN1, TESKARI ? LOW : HIGH);
  digitalWrite(IN2, TESKARI ? HIGH : LOW);
  analogWrite(ENA, TEZLIK_YUQORI);
  akt_holat = 1;
}
void pastga() {
  digitalWrite(IN1, TESKARI ? HIGH : LOW);
  digitalWrite(IN2, TESKARI ? LOW : HIGH);
  analogWrite(ENA, TEZLIK_PAST);
  akt_holat = -1;
}
void akt_toxta() {
  digitalWrite(IN1, LOW);
  digitalWrite(IN2, LOW);
  analogWrite(ENA, 0);
  akt_holat = 0;
}

// ================= N20 =================
void n20_aylan(int yon) {               // yon: 1 = oldinga, -1 = orqaga
  bool fwd = (yon > 0) != N20_TESKARI;
  digitalWrite(IN3, fwd ? HIGH : LOW);
  digitalWrite(IN4, fwd ? LOW : HIGH);
  if (!n20_ishlayapti) {               // qisqa turtki, sekin tezlikda ham qo'zg'alsin
    analogWrite(ENB, 255);
    delay(80);
    n20_ishlayapti = true;
  }
  analogWrite(ENB, TEZLIK_N20);
}
void n20_toxta() {
  digitalWrite(IN3, LOW);
  digitalWrite(IN4, LOW);
  analogWrite(ENB, 0);
  n20_ishlayapti = false;
}

// ================= Buzzer =================
void buzzer(bool yoq) {
  if (yoq == buzzer_holat) return;
  buzzer_holat = yoq;
  if (AKTIV_BUZZER) digitalWrite(BUZZER, yoq ? HIGH : LOW);
  else if (yoq)     tone(BUZZER, 2000);
  else              noTone(BUZZER);
}

// ================= Tugmalar =================
bool yangi_bosish(int pin, int &oldingi, unsigned long &oxirgi) {
  int hozir = digitalRead(pin);
  bool natija = false;
  if (oldingi == HIGH && hozir == LOW && millis() - oxirgi > 200) {
    natija = true;
    oxirgi = millis();
  }
  oldingi = hozir;
  return natija;
}

// ================= Ekran =================
void xabar(const char *q1, const char *q2) {
  strncpy(xabar1, q1, 16); xabar1[16] = 0;
  strncpy(xabar2, q2, 16); xabar2[16] = 0;
  xabar_bor = true;
  xabar_vaqt = millis();
}

void qator_yoz(int qator, const char *matn, char *eski) {
  char toliq[17];
  snprintf(toliq, 17, "%-16s", matn);
  if (strcmp(toliq, eski) != 0) {      // faqat o'zgarganda yozamiz (miltillamasin)
    lcd.setCursor(0, qator);
    lcd.print(toliq);
    strcpy(eski, toliq);
  }
}

void holat_qatori(char *q2) {
  if (mpu_bor) {
    char t[8];
    dtostrf(harorat, 4, 1, t);
    float qiya = max(fabs(oldinga), fabs(yonga));
    snprintf(q2, 17, "T:%s%cC Ang:%d%c", t, GRADUS, (int)qiya, GRADUS);
  } else {
    strcpy(q2, "No MPU6050!");
  }
}

void ekranni_yangila() {
  if (millis() - ekran_oxirgi < 200) return;
  ekran_oxirgi = millis();

  char q1[17], q2[17];

  if (favqulod) {
    strcpy(q1, "!! EMERGENCY !!");
    strcpy(q2, sabab);
  }
  else if (xabar_bor && millis() - xabar_vaqt < XABAR_MS) {
    strcpy(q1, xabar1);
    strcpy(q2, xabar2);
  }
  else if (rejim == KUTISH) {
    xabar_bor = false;
    strcpy(q1, "Press START");
    holat_qatori(q2);
  }
  else if (rejim == SANASH) {
    xabar_bor = false;
    int qoldi = 3 - (int)((millis() - rejim_boshlandi) / 1000);
    if (qoldi < 1) qoldi = 1;
    strcpy(q1, "Attention! Start");
    snprintf(q2, 17, "Start: %d", qoldi);
  }
  else {
    xabar_bor = false;
    const char *akt = (akt_holat == 1) ? "UP" : (akt_holat == -1) ? "DN" : "--";
    const char *n20 = !n20_yoqiq ? "OFF" : (n20_yon == 1) ? "FWD" : (n20_yon == -1) ? "REV" : "---";
    snprintf(q1, 17, "N20:%s ACT:%s", n20, akt);
    holat_qatori(q2);
  }

  qator_yoz(0, q1, ekran1);
  qator_yoz(1, q2, ekran2);
}

// ================= Holatlar =================
void kutishga_ot() {
  rejim = KUTISH;
  rejim_boshlandi = millis();
  boshlandi = millis();                // aktuator pastga tushib oladi
  n20_yoqiq = false;
  buzzer(false);
}

void favqulod_boshlash(const char *s) {
  favqulod = true;
  fav_boshlandi = millis();
  n20_yoqiq = false;
  buzzer(false);
  strncpy(sabab, s, 16);
  sabab[16] = 0;
  Serial.print("EMERGENCY: ");
  Serial.println(sabab);
}

// ================= MPU6050 =================
int16_t oqi16() {
  uint8_t yuqori = Wire.read();
  uint8_t past = Wire.read();
  return (int16_t)((uint16_t)yuqori << 8 | past);
}

bool mpu_oqi(float &o, float &y, float &t) {
  Wire.beginTransmission(MPU);
  Wire.write(0x3B);
  if (Wire.endTransmission(false) != 0) return false;
  if (Wire.requestFrom(MPU, 8) != 8) return false;

  int16_t ax = oqi16();
  int16_t ay = oqi16();
  int16_t az = oqi16();
  int16_t traw = oqi16();

  o = atan2((float)ay, (float)az) * 180.0 / PI;
  y = atan2(-(float)ax, sqrt((float)ay * ay + (float)az * az)) * 180.0 / PI;
  t = traw / 340.0 + 36.53;            // MPU6050 chip harorati
  return true;
}

void mpu_sozla() {
  Wire.beginTransmission(MPU);
  Wire.write(0x6B);
  Wire.write(0);                       // sensorni uyg'otamiz
  if (Wire.endTransmission() != 0) {
    Serial.println("MPU6050 not found!");
    return;
  }
  delay(100);

  // Yoqilgandagi holatni "nol" deb olamiz
  float jam_o = 0, jam_y = 0;
  int soni = 0;
  for (int i = 0; i < 20; i++) {
    float o, y, t;
    if (mpu_oqi(o, y, t)) { jam_o += o; jam_y += y; harorat = t; soni++; }
    delay(10);
  }
  if (soni > 0) {
    nol_oldinga = jam_o / soni;
    nol_yonga = jam_y / soni;
    mpu_bor = true;
  }
}

void mpu_tekshir() {
  if (!mpu_bor || millis() - mpu_oxirgi < 50) return;
  mpu_oxirgi = millis();

  float o, y, t;
  if (!mpu_oqi(o, y, t)) return;

  oldinga = o - nol_oldinga;
  yonga = y - nol_yonga;
  harorat = t;

  if (fabs(oldinga) > OGISH_CHEGARA || fabs(yonga) > OGISH_CHEGARA) ogish_soni++;
  else ogish_soni = 0;

  if (!favqulod && ogish_soni >= 3) {
    char s[17];
    int q = (int)max(fabs(oldinga), fabs(yonga));
    snprintf(s, 17, "Tilt: %d%c", q, GRADUS);
    favqulod_boshlash(s);
  }

  if (!favqulod && harorat > HARORAT_CHEGARA) {
    favqulod_boshlash("MOTOR OVERHEAT");
  }
}

// ================= Asosiy =================
void setup() {
  pinMode(ENA, OUTPUT); pinMode(IN1, OUTPUT); pinMode(IN2, OUTPUT);
  pinMode(ENB, OUTPUT); pinMode(IN3, OUTPUT); pinMode(IN4, OUTPUT);
  pinMode(TUGMA_AKT, INPUT_PULLUP);
  pinMode(TUGMA_N20, INPUT_PULLUP);
  pinMode(TUGMA_FAVQULOD, INPUT_PULLUP);
  pinMode(TUGMA_START, INPUT_PULLUP);
  pinMode(CHIROQ, OUTPUT);
  pinMode(BUZZER, OUTPUT);
  n20_toxta();
  akt_toxta();

  Serial.begin(9600);
  Wire.begin();
  Wire.setWireTimeout(3000, true);     // sensor uzilsa, Arduino qotib qolmasin

  lcd.init();
  lcd.backlight();
  lcd.setCursor(0, 0);
  lcd.print("Loading...");

  mpu_sozla();

  kutishga_ot();
  xabar("System ready", mpu_bor ? "MPU6050 OK" : "No MPU6050!");
}

void loop() {
  // ===== 1. Sensor =====
  mpu_tekshir();

  // ===== 2. Favqulod tugma =====
  if (yangi_bosish(TUGMA_FAVQULOD, fav_oldingi, fav_oxirgi_bosish)) {
    if (!favqulod) {
      favqulod_boshlash("Button pressed");
    }
    else if (ogish_soni > 0) {
      strcpy(sabab, "Still tilted!");
    }
    else if (harorat > HARORAT_CHEGARA - 5) {
      strcpy(sabab, "Still hot!");
    }
    else {
      favqulod = false;
      kutishga_ot();                   // qayta START talab qilinadi
      xabar("System ready", "Press START");
    }
  }

  // ===== 3. START tugmasi =====
  if (yangi_bosish(TUGMA_START, start_oldingi, start_oxirgi) && !favqulod) {
    if (rejim == KUTISH) {
      rejim = SANASH;
      rejim_boshlandi = millis();
      Serial.println("START pressed");
    }
    else if (rejim == ISHLAYAPTI) {
      kutishga_ot();                   // seansni tugatamiz
      xabar("Ride finished", "");
      Serial.println("Ride finished");
    }
  }

  // ===== 4. 3 soniyalik sanoq va buzzer =====
  if (rejim == SANASH && !favqulod) {
    unsigned long otdi = millis() - rejim_boshlandi;
    if (otdi >= SANASH_MS) {
      buzzer(false);
      rejim = ISHLAYAPTI;
      boshlandi = millis();
      oldingi_bosilgan = (digitalRead(TUGMA_AKT) == LOW);
      xabar("Ride started!", "Enjoy the ride!");
      Serial.println("Running");
    } else {
      buzzer(otdi % 500 < 300);        // 0,3 s ovoz, 0,2 s jimlik
    }
  }

  digitalWrite(CHIROQ, favqulod ? HIGH : LOW);

  // ===== 5. Ekran =====
  ekranni_yangila();

  // ===== 6. Favqulod holat =====
  if (favqulod) {
    n20_toxta();
    if (millis() - fav_boshlandi < KOTARISH_MS) yuqoriga();
    else                                        akt_toxta();
    return;
  }

  // ===== 7. Kutish yoki sanash: tugmalar ishlamaydi =====
  if (rejim != ISHLAYAPTI) {
    n20_toxta();
    if (millis() - boshlandi < yurish_vaqti(TEZLIK_PAST)) pastga();
    else                                                   akt_toxta();

    bool n20_b = yangi_bosish(TUGMA_N20, n20_oldingi, n20_oxirgi_bosish);
    bool akt_b = yangi_bosish(TUGMA_AKT, akt_k_oldingi, akt_k_oxirgi);
    if (rejim == KUTISH && (n20_b || akt_b)) {
      xabar("Press START", "to begin");
    }
    return;
  }

  // ===== 8. Aktuator: bosib turganda ko'tariladi, qo'yganda tushadi =====
  bool bosilgan = (digitalRead(TUGMA_AKT) == LOW);

  if (bosilgan != oldingi_bosilgan) {
    oldingi_bosilgan = bosilgan;
    boshlandi = millis();
    if (bosilgan) xabar("Actuator", "Moving up");
    else          xabar("Actuator", "Moving down");
  }

  unsigned long chegara = bosilgan ? yurish_vaqti(TEZLIK_YUQORI)
                                   : yurish_vaqti(TEZLIK_PAST);

  if (millis() - boshlandi > chegara) akt_toxta();
  else if (bosilgan)                  yuqoriga();
  else                                pastga();

  // ===== 9. N20: bir bosish — yoqiladi, yana bosish — o'chadi =====
  if (yangi_bosish(TUGMA_N20, n20_oldingi, n20_oxirgi_bosish)) {
    n20_yoqiq = !n20_yoqiq;
    if (n20_yoqiq) {
      n20_yon = 1;                     // har safar oldinga yo'nalishdan boshlaymiz
      n20_yon_boshlandi = millis();
      xabar("Motor ON", "Swinging");
    } else {
      xabar("Motor OFF", "");
    }
  }

  if (n20_yoqiq) {
    // oldinga N20_YON_MS → pauza → orqaga N20_YON_MS → pauza → ...
    static int keyingi_yon = -1;
    unsigned long otdi = millis() - n20_yon_boshlandi;
    if (n20_yon != 0) {
      if (otdi < N20_YON_MS) n20_aylan(n20_yon);
      else {                           // vaqt tugadi → qisqa pauza
        keyingi_yon = -n20_yon;
        n20_yon = 0;
        n20_yon_boshlandi = millis();
        n20_toxta();
      }
    } else {
      n20_toxta();
      if (otdi >= N20_PAUZA_MS) {      // pauza tugadi → teskari tomonga
        n20_yon = keyingi_yon;
        n20_yon_boshlandi = millis();
      }
    }
  } else {
    n20_toxta();
  }
}
