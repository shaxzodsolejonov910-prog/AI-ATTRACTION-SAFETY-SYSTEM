// TB6612FNG + N20 motor test (2026-10-10)
// Motor should spin in one direction at full speed.
// Result: motor did not move -> driver replaced with L298N.

void setup() {
  pinMode(4, OUTPUT);   // STBY
  pinMode(5, OUTPUT);   // PWMA
  pinMode(7, OUTPUT);   // AIN1
  pinMode(8, OUTPUT);   // AIN2

  digitalWrite(4, HIGH);
  digitalWrite(5, HIGH);  // full speed
  digitalWrite(7, HIGH);
  digitalWrite(8, LOW);
}

void loop() {
}
