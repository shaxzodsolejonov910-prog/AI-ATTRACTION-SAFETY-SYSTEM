// LCD 1602 (I2C) test (2026-10-28)
// Finds the LCD address automatically and prints a message on the screen.
// Library: "LiquidCrystal I2C" by Frank de Brabander

#include <Wire.h>
#include <LiquidCrystal_I2C.h>

void setup() {
  Serial.begin(9600);
  Wire.begin();
  Wire.setWireTimeout(3000, true);
  delay(300);

  byte lcdAddr = 0;
  for (byte a = 1; a < 127; a++) {
    Wire.beginTransmission(a);
    if (Wire.endTransmission() == 0) {
      Serial.print("Found: 0x");
      Serial.println(a, HEX);
      if (a >= 0x20 && a <= 0x3F) lcdAddr = a;   // LCD backpack address range
    }
  }

  if (lcdAddr == 0) {
    Serial.println("LCD not found");
    return;
  }

  LiquidCrystal_I2C *lcd = new LiquidCrystal_I2C(lcdAddr, 16, 2);
  lcd->init();
  lcd->backlight();
  lcd->print("It works!");
  lcd->setCursor(0, 1);
  lcd->print("Address: 0x");
  lcd->print(lcdAddr, HEX);
}

void loop() {}
