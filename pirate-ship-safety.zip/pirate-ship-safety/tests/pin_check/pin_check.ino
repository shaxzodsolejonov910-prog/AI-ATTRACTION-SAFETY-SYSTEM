// Analog pin check (2026-10-27)
// Disconnect every wire, then upload. With INPUT_PULLUP every pin should read OK.
// A0-A5 all read ERROR on the first board -> the board's analog pins were damaged.

void setup() {
  Serial.begin(9600);
  for (int p = A0; p <= A5; p++) pinMode(p, INPUT_PULLUP);
}

void loop() {
  const char *names[] = {"A0", "A1", "A2", "A3", "A4", "A5"};
  for (int i = 0; i < 6; i++) {
    Serial.print(names[i]);
    Serial.print(digitalRead(A0 + i) ? ":OK  " : ":ERROR  ");
  }
  Serial.println();
  delay(1000);
}
