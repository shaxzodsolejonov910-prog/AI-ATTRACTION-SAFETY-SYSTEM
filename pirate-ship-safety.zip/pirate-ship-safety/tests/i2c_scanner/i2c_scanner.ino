// I2C scanner with wire check (2026-10-27)
// 1) Checks that SDA/SCL are not shorted to GND
// 2) Lists every device on the I2C bus (LCD = 0x27, MPU6050 = 0x68)

#include <Wire.h>

void setup() {
  Serial.begin(9600);
  delay(500);
  Serial.println("=== Wire check ===");

  pinMode(A4, INPUT_PULLUP);
  pinMode(A5, INPUT_PULLUP);
  delay(10);
  Serial.print("SDA (A4): ");
  Serial.println(digitalRead(A4) ? "OK" : "ERROR - shorted to GND!");
  Serial.print("SCL (A5): ");
  Serial.println(digitalRead(A5) ? "OK" : "ERROR - shorted to GND!");

  Wire.begin();
  Wire.setWireTimeout(3000, true);   // do not hang if the bus is stuck
  Serial.println("=== Scanning ===");

  int count = 0;
  for (byte addr = 1; addr < 127; addr++) {
    Wire.beginTransmission(addr);
    byte result = Wire.endTransmission();
    if (result == 0) {
      Serial.print("Found: 0x");
      Serial.println(addr, HEX);
      count++;
    }
    if (Wire.getWireTimeoutFlag()) {
      Serial.println("ERROR: bus stuck");
      Wire.clearWireTimeoutFlag();
      break;
    }
  }
  if (count == 0) Serial.println("Nothing found");
  Serial.println("=== Done ===");
}

void loop() {}
